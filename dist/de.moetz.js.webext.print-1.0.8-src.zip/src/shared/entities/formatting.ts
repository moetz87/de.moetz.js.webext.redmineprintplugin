export class Formatting {

    constructor(
        public fontSize = 14,
        public fontBold = false) {

    }

}
